const sections=["home","register","login","draw"];
function show(id){sections.forEach(x=>document.getElementById(x).classList.add("hidden"));document.getElementById(id).classList.remove("hidden")}
async function api(u,o={}){const r=await fetch(u,{credentials:"same-origin",...o,headers:{"Content-Type":"application/json",...(o.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.error||"Erè");return d}
function esc(x){const d=document.createElement("div");d.textContent=x??"";return d.innerHTML}

document.getElementById("registerForm").onsubmit=async e=>{
 e.preventDefault();
 try{
  await api("/api/register",{method:"POST",body:JSON.stringify({name:rName.value,email:rEmail.value,password:rPassword.value})});
  show("draw");load();
 }catch(x){alert(x.message)}
};

document.getElementById("loginForm").onsubmit=async e=>{
 e.preventDefault();
 try{await api("/api/login",{method:"POST",body:JSON.stringify({email:lEmail.value,password:lPassword.value})});show("draw");load()}
 catch(x){alert(x.message)}
};

async function load(){
 const me=await api("/api/me");
 if(!me.loggedIn)return show("login");
 userName.textContent=me.user.name;
 if(me.user.selected_number)selected.innerHTML=`<b>Nimewo ou:</b> ${me.user.selected_number}`;
 const n=await api("/api/numbers");
 numbers.innerHTML="";
 for(let i=1;i<=100;i++){
  const b=document.createElement("button");b.textContent=i;b.className="number";
  if(n.taken.includes(i)){b.disabled=true;b.classList.add("taken")}
  b.onclick=()=>choose(i);numbers.appendChild(b);
 }
 const w=await api("/api/winner");
 if(w.drawn&&w.winner){winner.classList.remove("hidden");winner.innerHTML=`<h2>🎉 FELISITASYON!</h2><p>Ou genyen!</p><p>Nimewo: <b>${w.number}</b></p><div class="gift">🎁<br>${esc(w.gift)}</div>`}
}
async function choose(number){
 if(!confirm(`Èske ou sèten ou vle nimewo ${number}?`))return;
 try{await api("/api/choose-number",{method:"POST",body:JSON.stringify({number})});await load();alert(`Nimewo ${number} anrejistre!`)}
 catch(x){alert(x.message);load()}
}
async function logout(){await api("/api/logout",{method:"POST"});show("home")}
function setLang(l){
 if(l==="fr"){heroTitle.textContent="Choisissez votre numéro.";heroText.textContent="Inscrivez-vous, choisissez un numéro de 1 à 100 et participez au tirage."}
 else if(l==="en"){heroTitle.textContent="Choose your number.";heroText.textContent="Register, choose a number from 1 to 100 and enter the draw."}
 else {heroTitle.textContent="Chwazi nimewo ou.";heroText.textContent="Enskri, chwazi yon nimewo ant 1 ak 100 epi patisipe nan tiraj la."}
}
(async()=>{try{const m=await api("/api/me");m.loggedIn?show("draw"):show("home");if(m.loggedIn)load()}catch{show("home")}})();