require("dotenv").config();

const express = require("express");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is missing.");
  process.exit(1);
}
if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD || !process.env.SESSION_SECRET) {
  console.error("ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET are required.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

app.set("trust proxy", 1);
app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));

app.use(session({
  store: new pgSession({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false
});

const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
      selected_number INTEGER UNIQUE CHECK (selected_number BETWEEN 1 AND 100),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS draw (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      winner_user_id BIGINT REFERENCES users(id),
      winner_number INTEGER,
      gift TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  const email = process.env.ADMIN_EMAIL.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);

  await pool.query(
    `INSERT INTO users (name,email,password_hash,role)
     VALUES ('PIPO WIN ADMIN',$1,$2,'admin')
     ON CONFLICT (email)
     DO UPDATE SET role='admin'`,
    [email, passwordHash]
  );

  console.log("Database ready.");
}

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Ou dwe konekte." });
  next();
}

async function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Ou dwe konekte." });

  try {
    const { rows } = await pool.query(
      `SELECT id,name,email,role FROM users WHERE id=$1`,
      [req.session.userId]
    );
    if (!rows[0] || rows[0].role !== "admin") {
      return res.status(403).json({ error: "Aksè admin refize." });
    }
    req.admin = rows[0];
    next();
  } catch {
    res.status(500).json({ error: "Erè server." });
  }
}

app.get("/", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/register", registerLimiter, async (req,res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (name.length < 2 || !email || password.length < 8)
      return res.status(400).json({ error: "Ranpli tout chan yo. Modpas la dwe gen omwen 8 karaktè." });

    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO users(name,email,password_hash,role)
       VALUES($1,$2,$3,'user') RETURNING id`,
      [name,email,passwordHash]
    );

    req.session.regenerate(err => {
      if (err) return res.status(500).json({error:"Session echwe."});
      req.session.userId = result.rows[0].id;
      res.json({success:true});
    });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({error:"Email sa deja anrejistre."});
    console.error(e);
    res.status(500).json({error:"Enskripsyon echwe."});
  }
});

app.post("/api/login", loginLimiter, async (req,res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const { rows } = await pool.query(
      `SELECT * FROM users WHERE email=$1`,
      [email]
    );
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password,user.password_hash)))
      return res.status(401).json({error:"Email oswa modpas pa kòrèk."});

    req.session.regenerate(err => {
      if (err) return res.status(500).json({error:"Koneksyon echwe."});
      req.session.userId = user.id;
      res.json({success:true,role:user.role});
    });
  } catch {
    res.status(500).json({error:"Erè server."});
  }
});

app.post("/api/logout",(req,res) => {
  req.session.destroy(() => res.json({success:true}));
});

app.get("/api/me", async (req,res) => {
  if (!req.session.userId) return res.json({loggedIn:false});
  const { rows } = await pool.query(
    `SELECT id,name,email,role,selected_number FROM users WHERE id=$1`,
    [req.session.userId]
  );
  if (!rows[0]) return res.json({loggedIn:false});
  res.json({loggedIn:true,user:rows[0]});
});

app.get("/api/numbers", async (req,res) => {
  const { rows } = await pool.query(
    `SELECT selected_number FROM users WHERE selected_number IS NOT NULL`
  );
  res.json({taken:rows.map(r=>r.selected_number)});
});

app.post("/api/choose-number", requireLogin, async (req,res) => {
  const number = Number(req.body.number);
  if (!Number.isInteger(number) || number < 1 || number > 100)
    return res.status(400).json({error:"Chwazi yon nimewo ant 1 ak 100."});

  try {
    const result = await pool.query(
      `UPDATE users SET selected_number=$1
       WHERE id=$2 AND selected_number IS NULL
       RETURNING selected_number`,
      [number,req.session.userId]
    );
    if (result.rowCount) return res.json({success:true,number});
    return res.status(409).json({error:"Ou deja chwazi yon nimewo oswa nimewo sa pa disponib."});
  } catch(e) {
    if (e.code === "23505") return res.status(409).json({error:"Nimewo sa deja pran."});
    res.status(500).json({error:"Pa kapab chwazi nimewo a."});
  }
});

app.get("/api/admin/participants", requireAdmin, async (req,res) => {
  const { rows } = await pool.query(
    `SELECT id,name,email,selected_number,created_at
     FROM users WHERE role='user' ORDER BY created_at DESC`
  );
  res.json({participants:rows});
});

app.get("/api/admin/status", requireAdmin, async (req,res) => {
  const { rows } = await pool.query(`SELECT * FROM draw WHERE id=1`);
  res.json({draw:rows[0] || null});
});

app.post("/api/admin/draw", requireAdmin, async (req,res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query(`SELECT * FROM draw WHERE id=1 FOR UPDATE`);
    if (existing.rows[0]) {
      await client.query("ROLLBACK");
      return res.status(409).json({error:"Tiraj la deja fèt."});
    }

    const participants = await client.query(
      `SELECT id,name,email,selected_number
       FROM users
       WHERE role='user' AND selected_number IS NOT NULL`
    );

    if (!participants.rows.length) {
      await client.query("ROLLBACK");
      return res.status(400).json({error:"Pa gen patisipan ki chwazi nimewo."});
    }

    const winner = participants.rows[crypto.randomInt(0,participants.rows.length)];
    const gifts = [
      "🎁 Gwo sipriz PIPO WIN",
      "🎉 Kado espesyal PIPO WIN",
      "💝 Yon bèl kado pou gayan an",
      "🏆 Pri espesyal PIPO WIN",
      "🎊 Surprise Winner"
    ];
    const gift = gifts[crypto.randomInt(0,gifts.length)];

    await client.query(
      `INSERT INTO draw(id,winner_user_id,winner_number,gift)
       VALUES(1,$1,$2,$3)`,
      [winner.id,winner.selected_number,gift]
    );

    await client.query("COMMIT");
    res.json({success:true,winner:{name:winner.name,number:winner.selected_number}});
  } catch(e) {
    await client.query("ROLLBACK");
    console.error(e);
    res.status(500).json({error:"Tiraj echwe."});
  } finally {
    client.release();
  }
});

app.get("/api/winner", requireLogin, async (req,res) => {
  const { rows } = await pool.query(`SELECT * FROM draw WHERE id=1`);
  if (!rows[0]) return res.json({drawn:false});
  if (String(rows[0].winner_user_id) !== String(req.session.userId))
    return res.json({drawn:true,winner:false});
  res.json({
    drawn:true,winner:true,
    number:rows[0].winner_number,
    gift:rows[0].gift
  });
});

app.get("/admin", requireAdmin, (req,res) => {
  res.sendFile(path.join(__dirname,"public","admin.html"));
});

initDb()
  .then(() => app.listen(PORT,() => console.log(`PIPO WIN running on ${PORT}`)))
  .catch(err => {
    console.error("Startup error:",err);
    process.exit(1);
  });
